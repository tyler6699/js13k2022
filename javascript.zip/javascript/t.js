c.fillStyle="#5C94FC";
c.fillRect(0,0,1024,32);
c.fillStyle="#00A800";
c.fillRect(256,0,32,32);
c.fillStyle="#000";
c.fillRect(944,0,64,32);